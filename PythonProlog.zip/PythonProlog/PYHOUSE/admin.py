from django.contrib import admin
from .models import Casa, Ubicacion, Servicio, Habitacion, Mobiliario

# Register your models here.
class CasaAdmin(admin.ModelAdmin):
    filter_horizontal = ("servicios","habitaciones","mobiliarios",)


admin.site.register(Casa, CasaAdmin)
admin.site.register(Ubicacion)
admin.site.register(Servicio)
admin.site.register(Habitacion)
admin.site.register(Mobiliario)