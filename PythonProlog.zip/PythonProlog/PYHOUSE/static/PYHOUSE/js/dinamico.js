// GLOBAL VARs
var dataProlog;

// Main Function
document.addEventListener('DOMContentLoaded', function() {
	restart();
	loadListeners();

	// Load GRAPHICS
	
});

///// FUNCTIONS TO CONSUME MY API WEB SERVICE  /////
function loadListeners()
{
	document.querySelector('#btn-search').addEventListener('click', () => fetchServer());
}

function fetchServer()
{
	try
	{
		const csrftoken = document.querySelector('[name=csrfmiddlewaretoken]').value;

		var ubicacion = document.querySelector('#ubicacion').value;
		var superficie = $("#superficie").val();
	    var precio = $("#precio").val();
		var servicios = getListOf('servicio');
		var habitaciones = getListOf('habitacion');
		var mobiliarios = getListOf('mobiliario');

		if (servicios === "[]" || habitaciones === "[]" || mobiliarios === "[]") 
		{
			alertError({"message":"Debe Elegir al menos un Servicio, Habitacion y Mobiliario", "error":"Por favor elija un Servicio, Habitacion y Mobiliario, estos datos son necesarios para calcular porcentajes de Match"});
		}
		else
		{
			var formData = new FormData();
		    formData.append("superficie", superficie);
		    formData.append("precio", precio);
		    formData.append("ubicacion",ubicacion);
		    formData.append("habitaciones", habitaciones);
		    formData.append("mobiliarios", mobiliarios);
		    formData.append("servicios", servicios);


			fetch('/search', {
		    	headers: {
		    		'X-CSRFToken': csrftoken 
		    	}, 
		    	method: 'POST',
		    	body: formData
		    })
			  .then(response => response.json())
			  .then(result => {

			  	// Print Result Alert

			  	document.querySelector('#graficos').innerHTML = '';
		    	if (result.data) 
		    	{
		    		if (result.data.length > 0) 
		    		{
		    			for (var i = 0; i < result.data.length; i++) {
		    				renderGraphics(document.querySelector('#graficos'),result.data[i]);
		    				console.log(result.data[i]);
		    			}
		    		}
		    		else
		    		{
		    			alertError({"message":"No pudimos encontrar Casas con tus Necesidades", "error":"NO MATCH QUERY"});
		    		}
		    	}
		    	else
		    	{
					alertError(result);
		    	}

			 });
		}

	}
	catch (e)
	{
		console.log(e);
	}
    
}

function getListOf(type)
{
	var out = "[";

	document.querySelectorAll('input').forEach(input => {
		
		if(input.id.startsWith(type))
		{
			if ($("#"+input.id+":checked").val() === "on")
			{
				out += document.querySelector('#txt_'+input.id).innerHTML.toLowerCase().replace(" ","_")+",";
			}
		}

	});

	if(out.length > 1)
		out = out.substring(0, out.length - 1)+"]";
	else
		out += "]";

	return out;
}


///// FUNCTIONS TO RENDER MY GRAPHICS  /////
function restart() {
	$("#felicidades").hide();
	$("#encontro").hide();
	$("#siento").hide();
}

function renderGraphics(parent,data){

	myRow = document.createElement('div');
	myRow.className = 'row border p-3 mb-5';

		divChartPie = document.createElement('div');
		divChartPie.className = 'col-12';

			inside = document.createElement('div');
			inside.className = 'row';

				tittle = document.createElement('div');
				tittle.className = 'col-12';
				tittle.innerHTML = '<h4>'+data.casa.replace("_"," ").toUpperCase()+'</h4>';

				chartPie = document.createElement('div');
				chartPie.className = 'col-12';
				chartPie.innerHTML = '<div id="piechart_'+data.id+'" class="w-auto mx-auto"></div>';

		

			inside.append(tittle);
			inside.append(chartPie);

		divChartPie.append(inside);

	divTable = document.createElement('div');
	divTable.className = 'col-12';
	divTable.innerHTML = '<div id="table_div_'+data.id+'" class="mx-auto" ></div>';


	myRow.append(divChartPie);
	myRow.append(divTable);

	parent.append(myRow);

	buildCharts(data);

}

function buildCharts(casa){
	google.charts.load('current', {'packages':['corechart']});
	google.setOnLoadCallback(function(){
		var data = google.visualization.arrayToDataTable([
          ['Coincidencia', 'Porcentaje'],
          ['Match con Habitaciones', parseFloat(casa.promedio_habitaciones)],
          ['Match con Servicios',      parseFloat(casa.promedio_servicios)],
          ['Match con Mobiliario',  parseFloat(casa.promedio_mobiliario)]
        ]);

	    var options = {
	      title: 'Porcentaje de Coincidencias con tu Busqueda'
	    };

	    var chart = new google.visualization.PieChart(document.getElementById('piechart_'+casa.id));

	    chart.draw(data, options);
	});

	google.charts.load('current', {'packages':['table']});
	google.charts.setOnLoadCallback(function(){
		var data = new google.visualization.DataTable();
        data.addColumn('string', 'Info');
        data.addColumn('string', 'Valor');

        if (casa.ubicacion) 
        {
        	var myUbicacion = casa.ubicacion[0].toUpperCase() + casa.ubicacion.slice(1); 
        	data.addRows([
	          ['Precio',  '$'+casa.precio],
	          ['Superficie',  casa.superficie+' m2'],
	          ['Ubicacion',  myUbicacion]
	        ]);
        }
        else
        {
        	data.addRows([
	          ['Precio',  '$'+casa.precio],
	          ['Superficie',  casa.superficie+' m2'],
	          ['Ubicacion',  document.querySelector('#ubicacion').options[document.querySelector('#ubicacion').selectedIndex].text]
	        ]);
        }

    	var table = new google.visualization.Table(document.getElementById('table_div_'+casa.id));

    	table.draw(data, {showRowNumber: true, width: '100%', height: '100%'});
	});
}

///// FUNTIONS TO DINAMIC ALERTS /////

// Funtion to display a Error Alert 
function alertError(result)
{
	document.querySelector('#myAlert_Tittle').innerHTML = 'Error';
	document.querySelector('#myAlert_Body').className = 'text-center d-block';
	document.querySelector('#myAlert_Message').className = 'alert alert-danger';
	document.querySelector('#myAlert_Message').innerHTML = result.message;
	document.querySelector('#myAlert_Extras').innerHTML = result.error;
	document.querySelector('#myAlert_Btn').className = 'btn btn-danger';

	$('#myAlert').modal('show');
}