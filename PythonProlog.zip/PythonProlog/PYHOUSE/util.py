import json
import re
import os
from os import system

def makeFileProlog(data):
	# CODE TO MAKE MY DINAMIC FILE PROLOG
	file = open("MEDIA/myPROLOG.pl", "w")

	# Write Casas
	for casa in data['data']:
		file.write(f"casa({casa['nombre']}).\n")
	file.write(f"{os.linesep}")

	# Write Servicios
	for casa in data['data']:
		file.write(f"servicios({casa['nombre']}, {casa['servicios']}).\n")
	file.write(f"{os.linesep}")

	# Write Habitaciones
	for casa in data['data']:
		file.write(f"habitaciones({casa['nombre']}, {casa['habitaciones']}).\n")
	file.write(f"{os.linesep}")

	# Write Mobiliarios
	for casa in data['data']:
		file.write(f"mobiliario({casa['nombre']}, {casa['mobiliarios']}).\n")
	file.write(f"{os.linesep}")

	# Write Superficie
	for casa in data['data']:
		file.write(f"superficie({casa['nombre']}, {casa['superficie']}).\n")
	file.write(f"{os.linesep}")

	# Write Ubicaciones
	for casa in data['data']:
		file.write(f"ubicacion({casa['nombre']}, {casa['ubicacion']}).\n")
	file.write(f"{os.linesep}")

	# Write Precios
	for casa in data['data']:
		file.write(f"precio({casa['nombre']}, {casa['precio']}).\n")
	file.write(f"{os.linesep}")

	# Write my RULES
	file.write("largo([],0).\n")
	file.write("largo([_|T],N):-largo(T,N0), N is N0 + 1.\n")
	file.write(f"{os.linesep}")


	file.write("member(X,[X|_]).\n")
	file.write("member(X,[_|T]):-member(X,T).\n")
	file.write(f"{os.linesep}")


	file.write("co([],_,0).\n")
	file.write("co([X|T],L2,C):-member(X,L2),co(T,L2,C2),C is C2 + 1.\n")
	file.write("co([X|T],L2,C):-not(member(X,L2)),co(T,L2,C2),C is C2.\n")
	file.write(f"{os.linesep}")


	file.write("myCasa(C,S,PMServicios,PCServicios,H,PMHabitaciones,PCHabitaciones,M,PMMobiliario,PCMobiliario,Presupuesto,Precio,GustoUbicacion,GustoSuperficie,Superficie):-casa(C),\n")
	file.write("\t\t\t\tservicios(C,CS),\n")
	file.write("\t\t\t\tlargo(CS,LargoA),largo(S,LargoB),\n")
	file.write("\t\t\t\tNGambos is LargoA + LargoB,\n")
	file.write("\t\t\t\tProm is NGambos / 2,\n")
	file.write("\t\t\t\tco(CS,S,Coincidencias),\n")
	file.write("\t\t\t\tPCServicios is ((Coincidencias/Prom)*100),\n")
	file.write("\t\t\t\tPCServicios>=PMServicios,\n")
	file.write("\t\t\t\thabitaciones(C,CH),\n")
	file.write("\t\t\t\tlargo(CH,LargoAH),largo(H,LargoBH),\n")
	file.write("\t\t\t\tNGambosH is LargoAH + LargoBH,\n")
	file.write("\t\t\t\tPromH is NGambosH / 2,\n")
	file.write("\t\t\t\tco(CH,H,CoincidenciasH),\n")
	file.write("\t\t\t\tPCHabitaciones is ((CoincidenciasH/PromH)*100),\n")
	file.write("\t\t\t\tPCHabitaciones>=PMHabitaciones,\n")
	file.write("\t\t\t\tmobiliario(C,CM),\n")
	file.write("\t\t\t\tlargo(CM,LargoAM),largo(M,LargoBM),\n")
	file.write("\t\t\t\tNGambosM is LargoAM + LargoBM,\n")
	file.write("\t\t\t\tPromM is NGambosM / 2,\n")
	file.write("\t\t\t\tco(CM,M,CoincidenciasM),\n")
	file.write("\t\t\t\tPCMobiliario is ((CoincidenciasM/PromM)*100),\n")
	file.write("\t\t\t\tPCMobiliario>=PMMobiliario,\n")
	file.write("\t\t\t\tprecio(C,PrecioCasa),\n")
	file.write("\t\t\t\tPrecio is (PrecioCasa*1),\n")
	file.write("\t\t\t\tPresupuesto>=Precio,\n")
	file.write("\t\t\t\tsuperficie(C,SuperficieCasa),\n")
	file.write("\t\t\t\tSuperficie is (SuperficieCasa*1),\n")
	file.write("\t\t\t\tGustoSuperficie>=Superficie,\n")
	file.write("\t\t\t\tubicacion(C,GustoUbicacion).\n")
	file.write(f"{os.linesep}")


	file.close()	

def runQuery(data):
	servicios = data['servicios']
	PMServicios = data['PMServicios']

	habitaciones = data['habitaciones']
	PMHabitaciones = data['PMHabitaciones']

	mobiliario = data['mobiliario']
	PMMobiliario = data['PMMobiliario']

	presupuesto = data['presupuesto']

	GustoUbicacion = data['GustoUbicacion']

	GustoSuperficie = data['GustoSuperficie']

	system(f"python PYHOUSE/runPROLOG.py {servicios} {PMServicios} {habitaciones} {PMHabitaciones} {mobiliario} {PMMobiliario} {presupuesto} {GustoUbicacion} {GustoSuperficie}")