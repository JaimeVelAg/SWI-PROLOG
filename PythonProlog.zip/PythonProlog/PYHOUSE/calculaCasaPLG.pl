casa(casa_pedregal).
casa(casa_altozano).

habitaciones(casa_pedregal, [cocina, bano, cochera, recamara_principal, cuarto_servicio]).
habitaciones(casa_altozano, [cocina, bano, cochera, recamara_principal, cuarto_servicio, sala, comedor, estudio, patio]).

servicios(casa_pedregal, [luz, agua]).
servicios(casa_altozano, [luz, agua, internet, drenaje, telefono, correo]).

mobiliario(casa_pedregal, [mesa, refrigerador, armario, estufa]).
mobiliario(casa_altozano, [mesa, refrigerador, armario, estufa, personal_limpieza, mini_bar, cama]).

superficie(casa_pedregal, 480).
superficie(casa_altozano, 380).

ubicacion(casa_pedregal, centrico).
ubicacion(casa_altozano, zona_sur).

precio(casa_pedregal, 300000).
precio(casa_altozano, 400000).


largo([],0).
largo([_|T],N):-largo(T,N0), N is N0 + 1.

member(X,[X|_]).
member(X,[_|T]):-member(X,T).

co([],_,0).
co([X|T],L2,C):-member(X,L2),co(T,L2,C2),C is C2 + 1.
co([X|T],L2,C):-not(member(X,L2)),co(T,L2,C2),C is C2. 


myCasa(C,S,PMServicios,PCServicios,H,PMHabitaciones,PCHabitaciones,M,PMMobiliario,PCMobiliario,Presupuesto,Precio,GustoUbicacion,GustoSuperficie,Superficie):-casa(C),
                        servicios(C,CS),
                        largo(CS,LargoA),largo(S,LargoB),  
                        NGambos is LargoA + LargoB, 
                        Prom is NGambos / 2, 
                        co(CS,S,Coincidencias), 
                        PCServicios is ((Coincidencias/Prom)*100),
                        PCServicios>=PMServicios,
                        habitaciones(C,CH),
                        largo(CH,LargoAH),largo(H,LargoBH),  
                        NGambosH is LargoAH + LargoBH, 
                        PromH is NGambosH / 2, 
                        co(CH,H,CoincidenciasH), 
                        PCHabitaciones is ((CoincidenciasH/PromH)*100),
                        PCHabitaciones>=PMHabitaciones,
                        mobiliario(C,CM),
                        largo(CM,LargoAM),largo(M,LargoBM),  
                        NGambosM is LargoAM + LargoBM, 
                        PromM is NGambosM / 2, 
                        co(CM,M,CoincidenciasM), 
                        PCMobiliario is ((CoincidenciasM/PromM)*100),
                        PCMobiliario>=PMMobiliario,
                        precio(C,PrecioCasa),
                        Precio is (PrecioCasa*1),
                        Presupuesto>=Precio,
                        superficie(C,SuperficieCasa),
                        Superficie is (SuperficieCasa*1),
                        GustoSuperficie>=Superficie,
                        ubicacion(C,GustoUbicacion).