import json
import re
import os
from os import system
from django.core.files.base import ContentFile
from django.core.files.storage import default_storage
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render
from django.urls import reverse
from datetime import date
from datetime import datetime
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Casa, Ubicacion, Servicio, Habitacion, Mobiliario
from . import util

# Create your views here.
def index(request):
	return render(request,"PYHOUSE/index.html",{
    	"ubicaciones": Ubicacion.objects.all(),
    	"servicios": Servicio.objects.all(),
    	"habitaciones": Habitacion.objects.all(),
    	"mobiliarios": Mobiliario.objects.all()
    	})

def search(request):
	if request.method == "POST":
		# Make Object to Write File PROLOG	
		myCasas = Casa.objects.all()
		data = {}
		data['data'] = []
		for casa in myCasas:
			dataCasa = casa.serialize()

			strServicios = "["
			for servicio in casa.servicios.all():
				strServicios += f'{str(servicio).lower().replace(" ", "_")},'
			dataCasa['servicios'] = f"{strServicios.rstrip(strServicios[-1])}]"

			strHabitaciones = "["
			for habitacion in casa.habitaciones.all():
				strHabitaciones += f'{str(habitacion).lower().replace(" ", "_")},'
			dataCasa['habitaciones'] = f"{strHabitaciones.rstrip(strHabitaciones[-1])}]"
			
			strMobiliarios = "["
			for mobiliario in casa.mobiliarios.all():
				strMobiliarios += f'{str(mobiliario).lower().replace(" ", "_")},'
			dataCasa['mobiliarios'] = f"{strMobiliarios.rstrip(strMobiliarios[-1])}]"

			data['data'].append(dataCasa)

		# Write DINAMIC FILE PROLOG
		util.makeFileProlog(data)

		# Make Query Consult To PROLOG

		#maxSuperficie = Casa.objects.order_by("-superficie").first().superficie

		if request.POST["precio"] == '':
			myPrecio = float(Casa.objects.order_by("-precio").first().precio + 50)
		else:
			myPrecio = request.POST["precio"]

		if request.POST["superficie"] == '':
			mySuperficie = float(Casa.objects.order_by("-superficie").first().superficie + 50)
		else:
			mySuperficie = request.POST["superficie"]

		query = {}
		query['servicios'] = request.POST["servicios"]
		query['PMServicios'] = "1"
		query['habitaciones'] = request.POST["habitaciones"]
		query['PMHabitaciones'] = "1"
		query['mobiliario'] = request.POST["mobiliarios"]
		query['PMMobiliario'] = "1"
		query['presupuesto'] = myPrecio

		if request.POST["ubicacion"] == "0":
			query['GustoUbicacion'] = 'U'
		else:
			query['GustoUbicacion'] = str(Ubicacion.objects.get(id=request.POST["ubicacion"])).lower().replace(" ", "_")

		query['GustoSuperficie'] = mySuperficie


		util.runQuery(query)

		print(query)

		# Return JSON RESPONSE DATA
		try:
			with open("MEDIA/result.json") as jsonFile:
				jsonObject = json.load(jsonFile)
				jsonFile.close()

			return JsonResponse(jsonObject, safe=False)
		except Exception as e:
			return JsonResponse({
                    "message":"SERVER ERROR",
                    "error": str(e)
                }, status=201)

	else:
		return HttpResponse("Request Method Disabled")
