from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required

urlpatterns = [
    #Rutas para vistas
    path("", views.index, name="index"),
    path("search", views.search, name="search")
]
