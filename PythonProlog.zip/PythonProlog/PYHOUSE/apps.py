from django.apps import AppConfig


class PyhouseConfig(AppConfig):
    name = 'PYHOUSE'
