from django.db import models

# Create your models here.
class Servicio(models.Model):
	servicio = models.CharField(max_length=300)

	def  __str__(self):
		return f"{self.servicio}"

class Habitacion(models.Model):
	habitacion = models.CharField(max_length=300)

	def  __str__(self):
		return f"{self.habitacion}"

class Mobiliario(models.Model):
	mobiliario = models.CharField(max_length=300)

	def  __str__(self):
		return f"{self.mobiliario}"

class Ubicacion(models.Model):
	ubicacion = models.CharField(max_length=300)

	def  __str__(self):
		return f"{self.ubicacion}"

class Casa(models.Model):
	nombre = models.CharField(max_length=300)
	precio = models.DecimalField(max_digits=12, decimal_places=2)
	superficie = models.DecimalField(max_digits=12, decimal_places=2)
	ubicacion = models.ForeignKey(Ubicacion, on_delete=models.CASCADE, related_name="casaUbicacion")
	servicios = models.ManyToManyField(Servicio, blank=True, related_name="casaServicios")
	habitaciones = models.ManyToManyField(Habitacion, blank=True, related_name="casaHabitaciones")
	mobiliarios = models.ManyToManyField(Mobiliario, blank=True, related_name="casaMobiliarios")

	def  __str__(self):
		return f"{self.nombre}"

	def serialize(self):
		return {
			"id": self.id,
			"nombre": self.nombre.lower().replace(" ", "_"),
			"precio": float(self.precio),
			"superficie": float(self.superficie),
			"ubicacion": self.ubicacion.ubicacion.lower().replace(" ", "_")
		}