from os import system
from datetime import date
from datetime import datetime
from pyswip import Prolog
import os
import sys
import json


def serialize(id):
	return {
		"id": id,
		"created_at": datetime.now().strftime("%b %d %y, %I:%M %p")
	}


# CODE TO MAKE QUERY
# ------- myCasa(C,S,PMServicios,PCServicios,H,PMHabitaciones,PCHabitaciones,M,PMMobiliario,PCMobiliario,Presupuesto,Precio,GustoUbicacion,GustoSuperficie,Superficie)
query = f"myCasa(C,{str(sys.argv[1])},{str(sys.argv[2])},PCServicios,{str(sys.argv[3])},{str(sys.argv[4])},PCHabitaciones,{str(sys.argv[5])},{str(sys.argv[6])},PCMuebles,{str(sys.argv[7])},PR,{str(sys.argv[8])},{str(sys.argv[9])},Superficie)."


# CODE TO GET DATA PROLOG
prolog = Prolog()
prolog.consult("MEDIA/myPROLOG.pl")

data = {}
data['data'] = []
i = 0
for casa in prolog.query(query):
	dataCasa = serialize(i)

	if 'C' in casa.keys():
		dataCasa['casa'] = casa['C']

	if 'PCServicios' in casa.keys():
		dataCasa['promedio_servicios'] = casa['PCServicios']

	if 'PCHabitaciones' in casa.keys():
		dataCasa['promedio_habitaciones'] = casa['PCHabitaciones']

	if 'PCMuebles' in casa.keys():
		dataCasa['promedio_mobiliario'] = casa['PCMuebles']

	if 'PR' in casa.keys():
		dataCasa['precio'] = casa['PR']

	if 'Superficie' in casa.keys():
		dataCasa['superficie'] = casa['Superficie']

	if 'U' in casa.keys():
		dataCasa['ubicacion'] = casa['U']

	data['data'].append(dataCasa)
	i += 1

# CODE TO WRITE DATA PRLOG TO FORMAT JSON
with open('MEDIA/result.json', 'w') as jsonFile:
    json.dump(data, jsonFile)
    jsonFile.close()
