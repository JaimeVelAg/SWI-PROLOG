casa(casa_del_pedregal).
casa(casa_altozano).
casa(las_lomas).
casa(san_mateo).
casa(casa_azul).
casa(los_pinos).
casa(casa_roja).
casa(casa_rosa).
casa(casa_azulcrema).
casa(casa_rayada).
casa(san_nicolás).
casa(acatlán).
casa(casa_rojiblanca).
casa(casa_tigre).
casa(casa_lujo).
casa(casa_catedral).
casa(casa_de_gio).

servicios(casa_del_pedregal, [luz,agua]).
servicios(casa_altozano, [luz,agua,internet,drenaje]).
servicios(las_lomas, [luz,agua,drenaje]).
servicios(san_mateo, [luz,agua]).
servicios(casa_azul, [luz,agua,internet,tv_por_cable]).
servicios(los_pinos, [luz,agua,internet,drenaje,tv_por_cable,calentador_solar,gas]).
servicios(casa_roja, [luz,agua]).
servicios(casa_rosa, [luz,agua,internet,drenaje,tv_por_cable,alberca]).
servicios(casa_azulcrema, [luz]).
servicios(casa_rayada, [luz,agua,internet,drenaje,tv_por_cable,alberca]).
servicios(san_nicolás, [luz,agua,internet]).
servicios(acatlán, [luz,agua,internet,drenaje]).
servicios(casa_rojiblanca, [luz,agua,internet,tv_por_cable,gas]).
servicios(casa_tigre, [luz,agua,internet,drenaje,tv_por_cable,calentador_solar,gas]).
servicios(casa_lujo, [luz,agua,internet,drenaje,tv_por_cable,calentador_solar,gas,alberca,limpieza_semanal,asistente_virtual,personal_de_vigilancia]).
servicios(casa_catedral, [luz,agua,internet,drenaje,tv_por_cable,gas,limpieza_semanal,personal_de_vigilancia]).
servicios(casa_de_gio, [luz,agua,internet,drenaje,tv_por_cable,calentador_solar,gas,alberca,limpieza_semanal,asistente_virtual,personal_de_vigilancia]).

habitaciones(casa_del_pedregal, [sala,cocina]).
habitaciones(casa_altozano, [sala,cochera,cocina,wc]).
habitaciones(las_lomas, [sala,cocina,wc]).
habitaciones(san_mateo, [cocina,wc]).
habitaciones(casa_azul, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio,lavandería,gym]).
habitaciones(los_pinos, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio,lavandería,estudio,gym,cuarto_de_juegos,sala_de_cine]).
habitaciones(casa_roja, [wc,lavandería]).
habitaciones(casa_rosa, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio,lavandería,estudio,gym,cuarto_de_juegos,sala_de_cine]).
habitaciones(casa_azulcrema, [recamara_extra]).
habitaciones(casa_rayada, [sala,cochera,cocina,wc,patio_de_servicio,lavandería,estudio,gym,cuarto_de_juegos,sala_de_cine]).
habitaciones(san_nicolás, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio,lavandería]).
habitaciones(acatlán, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio]).
habitaciones(casa_rojiblanca, [cochera,cocina,wc,recamara_extra,patio_de_servicio,gym]).
habitaciones(casa_tigre, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio,lavandería,estudio]).
habitaciones(casa_lujo, [sala,cochera,cocina,wc,recamara_extra,patio_de_servicio,lavandería,estudio,gym,cuarto_de_juegos,sala_de_cine]).
habitaciones(casa_catedral, [sala,cochera,cocina,lavandería,estudio,gym,cuarto_de_juegos,sala_de_cine]).
habitaciones(casa_de_gio, [cocina]).

mobiliario(casa_del_pedregal, [mesa,refrigerador,cama]).
mobiliario(casa_altozano, [mesa,estufa,refrigerador,cama]).
mobiliario(las_lomas, [cama]).
mobiliario(san_mateo, [cama]).
mobiliario(casa_azul, [refrigerador,cama,juego_de_sofás,tv,consola_de_videojuegos]).
mobiliario(los_pinos, [mesa,estufa,refrigerador,cama,juego_de_sofás,tv,consola_de_videojuegos,tocador,pinturas,comedor]).
mobiliario(casa_roja, [cama,juego_de_sofás]).
mobiliario(casa_rosa, [mesa,estufa,refrigerador,cama,juego_de_sofás,tv,consola_de_videojuegos,tocador,pinturas,comedor]).
mobiliario(casa_azulcrema, [mesa,estufa]).
mobiliario(casa_rayada, [mesa,estufa,refrigerador,cama,juego_de_sofás,tv,comedor]).
mobiliario(san_nicolás, [refrigerador,cama,juego_de_sofás,consola_de_videojuegos]).
mobiliario(acatlán, [mesa,refrigerador,cama,juego_de_sofás,tv]).
mobiliario(casa_rojiblanca, [mesa,estufa,refrigerador,cama,juego_de_sofás,tv]).
mobiliario(casa_tigre, [mesa,estufa,refrigerador,cama,juego_de_sofás,tocador]).
mobiliario(casa_lujo, [mesa,estufa,refrigerador,cama,juego_de_sofás,tv,consola_de_videojuegos,tocador,pinturas,comedor]).
mobiliario(casa_catedral, [mesa,estufa,refrigerador,cama,juego_de_sofás,tocador,pinturas,comedor]).
mobiliario(casa_de_gio, [tv]).

superficie(casa_del_pedregal, 570.0).
superficie(casa_altozano, 575.0).
superficie(las_lomas, 450.0).
superficie(san_mateo, 35.0).
superficie(casa_azul, 100.0).
superficie(los_pinos, 500.0).
superficie(casa_roja, 20.0).
superficie(casa_rosa, 120.0).
superficie(casa_azulcrema, 10.0).
superficie(casa_rayada, 200.0).
superficie(san_nicolás, 39.0).
superficie(acatlán, 70.0).
superficie(casa_rojiblanca, 248.0).
superficie(casa_tigre, 300.0).
superficie(casa_lujo, 469.0).
superficie(casa_catedral, 378.0).
superficie(casa_de_gio, 2445.0).

ubicacion(casa_del_pedregal, pedregal).
ubicacion(casa_altozano, altozano).
ubicacion(las_lomas, zona_norte).
ubicacion(san_mateo, zona_sur).
ubicacion(casa_azul, santa_catarina).
ubicacion(los_pinos, zona_sur).
ubicacion(casa_roja, santa_catarina).
ubicacion(casa_rosa, polanco).
ubicacion(casa_azulcrema, apodaca).
ubicacion(casa_rayada, zapopan).
ubicacion(san_nicolás, san_nicolás).
ubicacion(acatlán, acatlán).
ubicacion(casa_rojiblanca, zapopan).
ubicacion(casa_tigre, san_nicolás).
ubicacion(casa_lujo, polanco).
ubicacion(casa_catedral, centro).
ubicacion(casa_de_gio, centro).

precio(casa_del_pedregal, 150000.0).
precio(casa_altozano, 250000.0).
precio(las_lomas, 899000.0).
precio(san_mateo, 200000.0).
precio(casa_azul, 200000.0).
precio(los_pinos, 1000000.0).
precio(casa_roja, 100000.0).
precio(casa_rosa, 700000.0).
precio(casa_azulcrema, 50000.0).
precio(casa_rayada, 800000.0).
precio(san_nicolás, 300000.0).
precio(acatlán, 400000.0).
precio(casa_rojiblanca, 900000.0).
precio(casa_tigre, 340000.0).
precio(casa_lujo, 2000000.0).
precio(casa_catedral, 1800000.0).
precio(casa_de_gio, 890000.0).

largo([],0).
largo([_|T],N):-largo(T,N0), N is N0 + 1.

member(X,[X|_]).
member(X,[_|T]):-member(X,T).

co([],_,0).
co([X|T],L2,C):-member(X,L2),co(T,L2,C2),C is C2 + 1.
co([X|T],L2,C):-not(member(X,L2)),co(T,L2,C2),C is C2.

myCasa(C,S,PMServicios,PCServicios,H,PMHabitaciones,PCHabitaciones,M,PMMobiliario,PCMobiliario,Presupuesto,Precio,GustoUbicacion,GustoSuperficie,Superficie):-casa(C),
				servicios(C,CS),
				largo(CS,LargoA),largo(S,LargoB),
				NGambos is LargoA + LargoB,
				Prom is NGambos / 2,
				co(CS,S,Coincidencias),
				PCServicios is ((Coincidencias/Prom)*100),
				PCServicios>=PMServicios,
				habitaciones(C,CH),
				largo(CH,LargoAH),largo(H,LargoBH),
				NGambosH is LargoAH + LargoBH,
				PromH is NGambosH / 2,
				co(CH,H,CoincidenciasH),
				PCHabitaciones is ((CoincidenciasH/PromH)*100),
				PCHabitaciones>=PMHabitaciones,
				mobiliario(C,CM),
				largo(CM,LargoAM),largo(M,LargoBM),
				NGambosM is LargoAM + LargoBM,
				PromM is NGambosM / 2,
				co(CM,M,CoincidenciasM),
				PCMobiliario is ((CoincidenciasM/PromM)*100),
				PCMobiliario>=PMMobiliario,
				precio(C,PrecioCasa),
				Precio is (PrecioCasa*1),
				Presupuesto>=Precio,
				superficie(C,SuperficieCasa),
				Superficie is (SuperficieCasa*1),
				GustoSuperficie>=Superficie,
				ubicacion(C,GustoUbicacion).

